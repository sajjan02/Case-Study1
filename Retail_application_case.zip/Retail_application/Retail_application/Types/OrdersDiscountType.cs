﻿namespace Retail_application.Types
{
    using HotChocolate.Types;
    using Retail_application.Models;

    public class OrdersDiscountType : ObjectType<OrdersDiscount>
    {
        protected override void Configure(IObjectTypeDescriptor<OrdersDiscount> descriptor)
        {
            descriptor.Field(od => od.OrderDiscountId).Type<NonNullType<IdType>>();
            descriptor.Field(od => od.OrderId).Type<IdType>();
            descriptor.Field(od => od.DiscountId).Type<IdType>();
            descriptor.Field(od => od.Discount).Type<DiscountType>();
            descriptor.Field(od => od.Order).Type<OrderType>();
        }
    }

}
