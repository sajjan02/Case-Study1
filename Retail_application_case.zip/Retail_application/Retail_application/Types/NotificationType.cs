﻿using HotChocolate.Types;
using Retail_application.Models;
namespace Retail_application.Types
{

    public class NotificationType : ObjectType<Notification>
    {
        protected override void Configure(IObjectTypeDescriptor<Notification> descriptor)
        {
            descriptor.Field(n => n.NotificationId).Type<NonNullType<IdType>>();
            descriptor.Field(n => n.UserId).Type<IdType>();
            descriptor.Field(n => n.Message).Type<StringType>();
            descriptor.Field(n => n.NotificationDate).Type<DateType>();
            descriptor.Field(n => n.User).Type<UserType>();
        }
    }

}
