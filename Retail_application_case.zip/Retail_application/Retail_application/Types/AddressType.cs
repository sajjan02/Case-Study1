﻿using HotChocolate.Types;
using Retail_application.Models;
using Retail_application.Types;

namespace Retail_application.Types
{
    public class AddressType : ObjectType<Address>
    {
        protected override void Configure(IObjectTypeDescriptor<Address> descriptor)
        {
            descriptor.Field(a => a.AddressId).Type<NonNullType<IdType>>();
            descriptor.Field(a => a.UserId).Type<IdType>();
            descriptor.Field(a => a.StreetAddress).Type<StringType>();
            descriptor.Field(a => a.City).Type<StringType>();
            descriptor.Field(a => a.State).Type<StringType>();
            descriptor.Field(a => a.PostalCode).Type<StringType>();
            descriptor.Field(a => a.Country).Type<StringType>();
            descriptor.Field(a => a.User).Type<UserType>();
        }
    }
}



