﻿using HotChocolate.Types;
using Retail_application.Models;

namespace Retail_application.Types
{
    public class CategoryType : ObjectType<Category>
    {
        protected override void Configure(IObjectTypeDescriptor<Category> descriptor)
        {
            descriptor.Field(c => c.CategoryId).Type<NonNullType<IdType>>();
            descriptor.Field(c => c.Name).Type<StringType>();
            descriptor.Field(c => c.ProductCategories).Type<ListType<ProductCategoryType>>();
        }
    }
}




