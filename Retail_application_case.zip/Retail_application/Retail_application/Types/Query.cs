﻿using HotChocolate;
using HotChocolate.Data;
using Microsoft.EntityFrameworkCore;
using Retail_application.Models;
using System.Linq;

public class Query
{


    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Order> GetOrders([ScopedService] RetailManagementContext context)
    {
        return context.Orders
                      .Include(o => o.OrderItems)
                      .Include(o => o.OrderPayments)
                      .Include(o => o.OrdersDiscounts)
                      .Include(o => o.Shipments)
                      .Include(o => o.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Category> GetCategories([ScopedService] RetailManagementContext context)
    {
        return context.Categories.Include(c => c.ProductCategories);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Address> GetAddresses([ScopedService] RetailManagementContext context)
    {
        return context.Addresses.Include(a => a.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Cart> GetCarts([ScopedService] RetailManagementContext context)
    {
        return context.Carts.Include(c => c.CartItems).Include(c => c.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<CartItem> GetCartItems([ScopedService] RetailManagementContext context)
    {
        return context.CartItems.Include(ci => ci.Cart).Include(ci => ci.Product);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Discount> GetDiscounts([ScopedService] RetailManagementContext context)
    {
        return context.Discounts.Include(d => d.OrdersDiscounts);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<InventoryTransaction> GetInventoryTransactions([ScopedService] RetailManagementContext context)
    {
        return context.InventoryTransactions.Include(it => it.Product);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Notification> GetNotifications([ScopedService] RetailManagementContext context)
    {
        return context.Notifications.Include(n => n.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<OrderItem> GetOrderItems([ScopedService] RetailManagementContext context)
    {
        return context.OrderItems.Include(oi => oi.Order).Include(oi => oi.Product);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<OrderPayment> GetOrderPayments([ScopedService] RetailManagementContext context)
    {
        return context.OrderPayments.Include(op => op.Order).Include(op => op.PaymentMethod);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<OrdersDiscount> GetOrdersDiscounts([ScopedService] RetailManagementContext context)
    {
        return context.OrdersDiscounts.Include(od => od.Order).Include(od => od.Discount);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<PaymentMethod> GetPaymentMethods([ScopedService] RetailManagementContext context)
    {
        return context.PaymentMethods.Include(pm => pm.OrderPayments);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Product> GetProducts([ScopedService] RetailManagementContext context)
    {
        return context.Products
                      .Include(p => p.CartItems)
                      .Include(p => p.InventoryTransactions)
                      .Include(p => p.OrderItems)
                      .Include(p => p.ProductCategories)
                      .Include(p => p.Reviews)
                      .Include(p => p.WishlistItems);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<ProductCategory> GetProductCategories([ScopedService] RetailManagementContext context)
    {
        return context.ProductCategories.Include(pc => pc.Product).Include(pc => pc.Category);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Review> GetReviews([ScopedService] RetailManagementContext context)
    {
        return context.Reviews.Include(r => r.Product).Include(r => r.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Shipment> GetShipments([ScopedService] RetailManagementContext context)
    {
        return context.Shipments.Include(s => s.Order);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<User> GetUsers([ScopedService] RetailManagementContext context)
    {
        return context.Users
                      .Include(u => u.Addresses)
                      .Include(u => u.Carts)
                      .Include(u => u.Notifications)
                      .Include(u => u.Orders)
                      .Include(u => u.Reviews)
                      .Include(u => u.Wishlists);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<Wishlist> GetWishlists([ScopedService] RetailManagementContext context)
    {
        return context.Wishlists.Include(w => w.WishlistItems).Include(w => w.User);
    }

    [UseDbContext(typeof(RetailManagementContext))]
    public IQueryable<WishlistItem> GetWishlistItems([ScopedService] RetailManagementContext context)
    {
        return context.WishlistItems.Include(wi => wi.Wishlist).Include(wi => wi.Product);
    }
    [UseDbContext(typeof(RetailManagementContext))]
    public IEnumerable<Product> GetProductsWithReviews(
           [ScopedService] RetailManagementContext context)
    {
        return context.Products
                      .Include(p => p.Reviews)  // Include reviews when fetching products
                      .ThenInclude(r => r.User) // Optionally, include user details for each review
                      .ToList();
    }
    [UseDbContext(typeof(RetailManagementContext))]
    public IEnumerable<Order> GetOrdersWithItemsAndProductDetails(
    [ScopedService] RetailManagementContext context)
    {
        return context.Orders
                      .Include(o => o.OrderItems)
                      .ThenInclude(oi => oi.Product) // Include product details for each order item
                      .ToList();
    }

    


}
