﻿using HotChocolate.Types;
using Retail_application.Models;
using Retail_application.Types;

namespace Retail_application.Types
{
    public class CartType : ObjectType<Cart>
    {
        protected override void Configure(IObjectTypeDescriptor<Cart> descriptor)
        {
            descriptor.Field(c => c.CartId).Type<NonNullType<IdType>>();
            descriptor.Field(c => c.UserId).Type<IdType>();
            descriptor.Field(c => c.CreatedDate).Type<DateType>();
            descriptor.Field(c => c.CartItems).Type<ListType<CartItemType>>();
            descriptor.Field(c => c.User).Type<UserType>();
        }
    }
}



