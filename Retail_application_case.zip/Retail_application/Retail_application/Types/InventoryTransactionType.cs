﻿using HotChocolate.Types;
using Retail_application.Models;

namespace Retail_application.Types
{
    public class InventoryTransactionType : ObjectType<InventoryTransaction>
    {
        protected override void Configure(IObjectTypeDescriptor<InventoryTransaction> descriptor)
        {
            descriptor.Field(it => it.TransactionId).Type<NonNullType<IdType>>();
            descriptor.Field(it => it.ProductId).Type<IdType>();
            descriptor.Field(it => it.TransactionDate).Type<DateType>();
            descriptor.Field(it => it.QuantityChange).Type<IntType>();
            descriptor.Field(it => it.Product).Type<ProductType>();
        }
    }
}



