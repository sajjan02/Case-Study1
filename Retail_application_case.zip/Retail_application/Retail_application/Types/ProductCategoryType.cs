﻿using HotChocolate.Types;
using Retail_application.Models;
namespace Retail_application.Types
{

    public class ProductCategoryType : ObjectType<ProductCategory>
    {
        protected override void Configure(IObjectTypeDescriptor<ProductCategory> descriptor)
        {
            descriptor.Field(pc => pc.ProductCategoryId).Type<NonNullType<IdType>>();
            descriptor.Field(pc => pc.ProductId).Type<IdType>();
            descriptor.Field(pc => pc.CategoryId).Type<IdType>();
            descriptor.Field(pc => pc.Category).Type<CategoryType>();
            descriptor.Field(pc => pc.Product).Type<ProductType>();
        }
    }

}

