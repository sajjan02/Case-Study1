﻿using HotChocolate.Types;
using Retail_application.Models;

namespace Retail_application.Types
{
    public class DiscountType : ObjectType<Discount>
    {
        protected override void Configure(IObjectTypeDescriptor<Discount> descriptor)
        {
            descriptor.Field(d => d.DiscountId).Type<NonNullType<IdType>>();
            descriptor.Field(d => d.Code).Type<StringType>();
            descriptor.Field(d => d.Description).Type<StringType>();
            descriptor.Field(d => d.DiscountPercentage).Type<DecimalType>();
            descriptor.Field(d => d.OrdersDiscounts).Type<ListType<OrdersDiscountType>>();
        }
    }
}



