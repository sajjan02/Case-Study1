﻿using HotChocolate.Types;
using Retail_application.Models;
namespace Retail_application.Types
{

    public class PaymentMethodType : ObjectType<PaymentMethod>
    {
        protected override void Configure(IObjectTypeDescriptor<PaymentMethod> descriptor)
        {
            descriptor.Field(pm => pm.PaymentMethodId).Type<NonNullType<IdType>>();
            descriptor.Field(pm => pm.MethodName).Type<StringType>();
            descriptor.Field(pm => pm.OrderPayments).Type<ListType<OrderPaymentType>>();
        }
    }

}
