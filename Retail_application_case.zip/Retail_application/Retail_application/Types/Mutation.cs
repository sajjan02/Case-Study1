﻿using HotChocolate;
using HotChocolate.Data;
using Retail_application.Models;
using System.Linq;

namespace Retail_application.Mutations
{
    public class Mutation
    {
        // Mutation for updating user profile information
        [UseDbContext(typeof(RetailManagementContext))]
        public User UpdateUserProfile(
            [ScopedService] RetailManagementContext context,
            int userId,
            string newEmail,
            AddressInput newAddress)
        {
            // Find the user by userId
            var user = context.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                throw new GraphQLException($"User with ID {userId} not found.");
            }

            // Update the user's email
            user.Email = newEmail;

            // Update the user's address
            var address = new Address
            {
                City = newAddress.City,
                State = newAddress.State,
                PostalCode = newAddress.PostalCode
            };
            user.Addresses.Add(address);

            // Save changes to the database
            context.SaveChanges();

            // Return the updated user information
            return user;
        }
    }

    // Input type for the address
    public class AddressInput
    {
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
    }
}
