﻿using HotChocolate.Types;
using Retail_application.Models;
namespace Retail_application.Types
{

    public class WishlistItemType : ObjectType<WishlistItem>
    {
        protected override void Configure(IObjectTypeDescriptor<WishlistItem> descriptor)
        {
            descriptor.Field(wi => wi.WishlistItemId).Type<NonNullType<IdType>>();
            descriptor.Field(wi => wi.WishlistId).Type<IdType>();
            descriptor.Field(wi => wi.ProductId).Type<IdType>();
            descriptor.Field(wi => wi.Product).Type<ProductType>();
            descriptor.Field(wi => wi.Wishlist).Type<WishlistType>();
        }
    }

}
