﻿using HotChocolate;
using HotChocolate.Subscriptions;
using Retail_application.Models;
using Retail_application.Subscriptions;
using System.Linq;
using System.Threading.Tasks;

namespace Retail_application.Mutations
{
    public class OrderMutation
    {
        public async Task<Order> UpdateOrderStatusAsync(
            int orderId,
            string newStatus,
            [Service] RetailManagementContext context,
            [Service] ITopicEventSender eventSender)
        {
            var order = context.Orders.FirstOrDefault(o => o.OrderId == orderId);
            if (order == null)
            {
                throw new GraphQLException(new Error("Order not found."));
            }

            order.Status = newStatus;
            context.SaveChanges();

            // Publish the status update event
            await eventSender.SendAsync(nameof(OrderSubscription.OnOrderStatusUpdatedAsync), order);

            return order;
        }
    }
}
