﻿using HotChocolate.Types;
using Retail_application.Models;
using Retail_application.Types;
namespace Retail_application.Types
{

    public class OrderItemType : ObjectType<OrderItem>
    {
        protected override void Configure(IObjectTypeDescriptor<OrderItem> descriptor)
        {
            descriptor.Field(oi => oi.OrderItemId).Type<NonNullType<IdType>>();
            descriptor.Field(oi => oi.OrderId).Type<IdType>();
            descriptor.Field(oi => oi.ProductId).Type<IdType>();
            descriptor.Field(oi => oi.Quantity).Type<IntType>();
            descriptor.Field(oi => oi.UnitPrice).Type<DecimalType>();
            descriptor.Field(oi => oi.Order).Type<OrderType>();
            descriptor.Field(oi => oi.Product).Type<ProductType>().Description("Details of the product associated with this order item"); ;
        }
    }

}

          
