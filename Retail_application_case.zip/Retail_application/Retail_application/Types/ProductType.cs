﻿using HotChocolate.Types;
using Retail_application.Models;
using Retail_application.Types;

namespace Retail_application.Types
{

    public class ProductType : ObjectType<Product>
    {
        protected override void Configure(IObjectTypeDescriptor<Product> descriptor)
        {
            descriptor.Field(p => p.ProductId).Type<NonNullType<IdType>>();
            descriptor.Field(p => p.Name).Type<StringType>();
            descriptor.Field(p => p.Price).Type<DecimalType>();
            descriptor.Field(p => p.InventoryCount).Type<IntType>();
            descriptor.Field(p => p.CartItems).Type<ListType<CartItemType>>();
            descriptor.Field(p => p.InventoryTransactions).Type<ListType<InventoryTransactionType>>();
            descriptor.Field(p => p.OrderItems).Type<ListType<OrderItemType>>();
            descriptor.Field(p => p.ProductCategories)
                .Type<ListType<ProductCategoryType>>()
                .ResolveWith<Resolvers>(r => r.GetCategories(default!));
            descriptor.Field(p => p.Reviews)
           .Type<ListType<ReviewType>>()
           .Description("List of reviews for the product");
            descriptor.Field(p => p.WishlistItems).Type<ListType<WishlistItemType>>();
            descriptor.Field(p => p.ProductCategories).Type<CategoryType>();



        }
        private class Resolvers
        {
            public IEnumerable<ProductCategory> GetCategories(Product product, [ScopedService] RetailManagementContext context)
            {
                return context.ProductCategories
                    .Where(pc => pc.ProductId == product.ProductId)
                    .Select(pc => new ProductCategory
                    {
                        Category = context.Categories.FirstOrDefault(c => c.CategoryId == pc.CategoryId)
                    })
                    .ToList();
            }

            internal object? GetCategories(Product product)
            {
                throw new NotImplementedException();
            }
        }

    }

}




        
            
        

       
    

