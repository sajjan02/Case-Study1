﻿using Retail_application.Models;
using Retail_application.Types;
using HotChocolate.Types;

namespace Retail_application.Types
{
    public class OrderType : ObjectType<Order>
    {
        protected override void Configure(IObjectTypeDescriptor<Order> descriptor)
        {
            descriptor.Field(o => o.OrderId).Type<NonNullType<IdType>>();
            descriptor.Field(o => o.UserId).Type<IdType>();
            descriptor.Field(o => o.OrderDate).Type<DateType>();
            descriptor.Field(o => o.TotalAmount).Type<DecimalType>();
            descriptor.Field(o => o.Status).Type<StringType>();
            descriptor.Field(o => o.OrderItems).Type<ListType<OrderItemType>>();
            descriptor.Field(o => o.OrderPayments).Type<ListType<OrderPaymentType>>();
            descriptor.Field(o => o.OrdersDiscounts).Type<ListType<OrdersDiscountType>>();
            descriptor.Field(o => o.Shipments).Type<ListType<ShipmentType>>();
            descriptor.Field(o => o.User).Type<UserType>();
        }
    }
}





