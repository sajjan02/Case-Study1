﻿using HotChocolate;
using HotChocolate.Subscriptions;
using Retail_application.Models;
using System.Threading.Tasks;

namespace Retail_application.Subscriptions
{
    public class OrderSubscription
    {
        [Subscribe]
        [Topic]
        public Task<Order> OnOrderStatusUpdatedAsync([EventMessage] Order order) => Task.FromResult(order);
    }
}
