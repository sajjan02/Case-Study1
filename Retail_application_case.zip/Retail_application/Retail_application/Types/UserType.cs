﻿using Microsoft.VisualBasic;
using HotChocolate.Types;
using Retail_application.Models;

namespace Retail_application.Types
{
    public class UserType : ObjectType<User>
    {
        protected override void Configure(IObjectTypeDescriptor<User> descriptor)
        {
            descriptor.Field(u => u.UserId).Type<NonNullType<IdType>>();
            descriptor.Field(u => u.FirstName).Type<StringType>();
            descriptor.Field(u => u.LastName).Type<StringType>();
            descriptor.Field(u => u.Email).Type<StringType>();
            descriptor.Field(u => u.Phone).Type<StringType>();
            descriptor.Field(u => u.Addresses).Type<ListType<AddressType>>();
            descriptor.Field(u => u.Carts).Type<ListType<CartType>>();
            descriptor.Field(u => u.Notifications).Type<ListType<NotificationType>>();
            descriptor.Field(u => u.Orders).Type<ListType<OrderType>>();
            descriptor.Field(u => u.Reviews).Type<ListType<ReviewType>>();
            descriptor.Field(u => u.Wishlists).Type<ListType<WishlistType>>();
        }
    }
}



