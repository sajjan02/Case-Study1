﻿using HotChocolate.Types;
using Retail_application.Models;
using Retail_application.Types;

namespace Retail_application.Types
{
    public class CartItemType : ObjectType<CartItem>
    {
        protected override void Configure(IObjectTypeDescriptor<CartItem> descriptor)
        {
            descriptor.Field(ci => ci.CartItemId).Type<NonNullType<IdType>>();
            descriptor.Field(ci => ci.CartId).Type<IdType>();
            descriptor.Field(ci => ci.ProductId).Type<IdType>();
            descriptor.Field(ci => ci.Quantity).Type<IntType>();
            descriptor.Field(ci => ci.Cart).Type<CartType>();
            descriptor.Field(ci => ci.Product).Type<ProductType>();
        }
    }
}



