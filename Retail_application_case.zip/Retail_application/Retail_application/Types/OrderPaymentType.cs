﻿using HotChocolate.Types;
using Retail_application.Models;
namespace Retail_application.Types
{

    public class OrderPaymentType : ObjectType<OrderPayment>
    {
        protected override void Configure(IObjectTypeDescriptor<OrderPayment> descriptor)
        {
            descriptor.Field(op => op.OrderPaymentId).Type<NonNullType<IdType>>();
            descriptor.Field(op => op.OrderId).Type<IdType>();
            descriptor.Field(op => op.PaymentMethodId).Type<IdType>();
            descriptor.Field(op => op.Amount).Type<DecimalType>();
            descriptor.Field(op => op.Order).Type<OrderType>();
            descriptor.Field(op => op.PaymentMethod).Type<PaymentMethodType>();
        }
    }

}
