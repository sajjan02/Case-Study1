﻿namespace RestCaseStudyLibrary
{
    public class Class1
    {

    }
}
