﻿using RestCaseStudyLibrary.Data;
using RestCaseStudyLibrary.Models;
using RestCaseStudyLibrary.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestCaseStudyLibrary.Repo
{
    public class UserClass : IUser
    {
        RetailManagement1Context _context;
        public UserClass(RetailManagement1Context retailManagement1Context)
        {
            _context = retailManagement1Context;
        }

        //List<User> GetAllUser()
        //{
        //    List<User> list = _context.Users.ToList();
        //    return list;
        //    //throw new NotImplementedException();
        //}
        //void AddUser(User user)
        //{
        //    _context.Add(user);
        //    _context.SaveChangesAsync();
        //    //throw new NotImplementedException();
        //}

        //User GetUserById(int id)
        //{
        //    User user = _context.Users.Where(u => u.UserId == id).FirstOrDefault();
        //    return user;
        //}

        //void DeleteUserById(int id)
        //{
        //    User user = _context.Users.Find(id);
        //    _context.Remove(user);
        //    _context.SaveChangesAsync();
        //    //throw new NotImplementedException();
        //}

        //void UpdateCustomer(User user)
        //{
        //    User exitCust = _context.Users.Find(user.UserId);

        //    if (exitCust != null)
        //    {
        //        exitCust.UserId = user.UserId;
        //        exitCust.FirstName = user.FirstName;
        //        exitCust.LastName = user.LastName;
        //        exitCust.Email = user.Email;
        //        _context.SaveChanges();
        //        //throw new NotImplementedException();
        //    }

        //}

        public List<User> GetAllUsers()
        {
            List<User> list = _context.Users.ToList();
            return list;
        }

        User IUser.GetUserById(int id)
        {
            User user = _context.Users.Where(u => u.UserId == id).FirstOrDefault();
            return user;
        }

        void IUser.AddUser(User user)
        {
            _context.Add(user);
            _context.SaveChangesAsync();
        }

        void IUser.DeleteUserById(int id)
        {
            User user = _context.Users.Find(id);
            _context.Remove(user);
            _context.SaveChangesAsync();
        }

        public void UpdateUser(User user)
        {
            User exitCust = _context.Users.Find(user.UserId);

            if (exitCust != null)
            {
                exitCust.UserId = user.UserId;
                exitCust.FirstName = user.FirstName;
                exitCust.LastName = user.LastName;
                exitCust.Email = user.Email;
                _context.SaveChanges();
                //throw new NotImplementedException();
            }
        }
    }
}
